% -*- Mode: Fundamental -*-

disp(' ');
disp('!!! Executing local CarMaker startup.m file found in your current working');
disp('!!! directory. This might shadow another startup.m that would normally be');
disp('!!! executed if this local file weren''t present.');
disp(' ');
disp('!!! You might want to incorporate the commands from this local file into');
disp('!!! your site''s Matlab setup. For details please refer to the Matlab');
disp('!!! documentation, chapter ''Starting and Quitting Matlab''.');
disp(' ');

cmenv;

