% Adaptive Cruise Control (ACC) Stateflow Chart Implementation in MATLAB
% This code uses MATLAB's Stateflow to implement the ACC system's modes
% Modes: OFF, STANDBY, ON (with sub-states)

% Define input signals
CruiseSwitch = 0; % Cruise control switch (0 = OFF, 1 = ON)
SetSwitch = 0;   % Set switch (0 = not set, 1 = set)
LeadVehicle_Detected = 0; % Lead vehicle detection (0 = not detected, 1 = detected)
Set_Speed = 100; % Set speed by driver (km/h)
DriveVehicle_Speed = 0; % Current speed of the vehicle
Time_Gap = 2.0; % Desired time gap between vehicles (seconds)

% Define initial state
current_state = 'OFF';

% Simulation loop (for demonstration purposes, iterate 100 times)
for t = 1:100
    fprintf('Time Step %d: Current State = %s\n', t, current_state);
    
    switch current_state
        case 'OFF'
            % ACC is turned off
            Acceleration_Mode = 0;
            fprintf('Acceleration Mode: %d\n', Acceleration_Mode);
            
            % Transition to STANDBY if CruiseSwitch is enabled
            if CruiseSwitch == 1
                current_state = 'STANDBY';
            end
        
        case 'STANDBY'
            % ACC is in standby mode
            Acceleration_Mode = 1;
            fprintf('Acceleration Mode: %d\n', Acceleration_Mode);
            
            % Transition to OFF if CruiseSwitch is disabled
            if CruiseSwitch == 0
                current_state = 'OFF';
            % Transition to ON if SetSwitch is enabled
            elseif SetSwitch == 1
                current_state = 'ON';
            end
        
        case 'ON'
            % ACC is active and controlling vehicle speed
            Acceleration_Mode = 2;
            fprintf('Acceleration Mode: %d\n', Acceleration_Mode);
            
            % Sub-states within ON mode
            if LeadVehicle_Detected == 1
                % Lead vehicle detected - Follow mode
                if DriveVehicle_Speed < Set_Speed
                    current_state = 'LeadVehicle_Detected_Follow';
                elseif DriveVehicle_Speed == Set_Speed && Time_Gap >= 1.5
                    current_state = 'LeadVehicle_Speed_equal_Set_Speed';
                else
                    current_state = 'LeadVehicle_Speed_less_than_Set_Speed';
                end
            else
                % No lead vehicle detected - Resume or cruise mode
                current_state = 'LeadVehicle_Not_Detected';
            end
        
        case 'LeadVehicle_Detected_Follow'
            % Lead vehicle detected, follow the vehicle
            Acceleration_Mode = 3;
            fprintf('Acceleration Mode: %d\n', Acceleration_Mode);
            % Transition conditions
            if LeadVehicle_Detected == 0
                current_state = 'LeadVehicle_Not_Detected';
            elseif LeadVehicle_Detected == 1 && DriveVehicle_Speed < Set_Speed
                current_state = 'LeadVehicle_Speed_less_than_Set_Speed';
            end
        
        case 'LeadVehicle_Not_Detected'
            % Lead vehicle not detected, resume to set speed
            Acceleration_Mode = 1;
            fprintf('Acceleration Mode: %d\n', Acceleration_Mode);
            % Transition conditions
            if LeadVehicle_Detected == 1
                current_state = 'LeadVehicle_Detected_Follow';
            end
        
        case 'LeadVehicle_Speed_less_than_Set_Speed'
            % Lead vehicle speed is less than set speed
            Acceleration_Mode = 4;
            fprintf('Acceleration Mode: %d\n', Acceleration_Mode);
            % Transition conditions
            if LeadVehicle_Detected == 0 && DriveVehicle_Speed == Set_Speed
                current_state = 'LeadVehicle_Not_Detected';
            elseif (LeadVehicle_Detected == 1 && DriveVehicle_Speed < Set_Speed)
                current_state = 'LeadVehicle_Speed_equal_Set_Speed';
            end
        
        case 'LeadVehicle_Speed_equal_Set_Speed'
            % Lead vehicle speed is equal to set speed
            Acceleration_Mode = 5;
            fprintf('Acceleration Mode: %d\n', Acceleration_Mode);
            % Transition conditions
            if LeadVehicle_Detected == 0
                current_state = 'LeadVehicle_Not_Detected_Resume';
            elseif DriveVehicle_Speed < Set_Speed && Time_Gap >= Set_Speed
                current_state = 'LeadVehicle_Detected_Resume';
            end
        
        otherwise
            error('Unknown state encountered');
    end
    
    % Pause for visualization in simulation (Optional)
    pause(0.1);
end
